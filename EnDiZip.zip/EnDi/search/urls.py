from django.urls import path
from . import views


app_name = 'search'
urlpatterns = [
	path('', views.search_html, name='search_html'),
	path('add_site/', views.site_html, name='site_html'),
	path('search/', views.search_logic, name='search_logic'),
	path('add_site/thanks/', views.thanks_html, name='thanks_html'),
	path('add_site/addsite/', views.add_site, name='add_site'),
	path('add_site/addsite_ex/', views.add_site_ex, name='add_site_ex'),
	path('add_site/addsite_rev/', views.add_site_rev, name='add_site_rev'),
]
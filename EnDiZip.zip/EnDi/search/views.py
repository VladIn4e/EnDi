from django.shortcuts import render

from django.http import HttpResponseRedirect, Http404
from django.shortcuts import render
from django.urls import reverse
from .models import Add_Site
from django.utils import timezone


def search_html(request):
    return render(request, 'search/index.html')

def site_add(request):
    return HttpResponseRedirect(reverse('sites:site_html'))

def search_logic(request):
    search_query = request.GET.get("word")

    if search_query != None and search_query != "":
        sites = Add_Site.objects.filter(
            site_title__startswith=search_query
        ).order_by('-id')
        if sites != None and sites != "":
            return render(request, 'search/search.html', {'sites': sites})
        else:
            raise Http404("Ничего не найдено :(")
    else:
        return render(request, 'search/index.html')

def site_html(request):
    return render(request, 'search/add/index.html')

def thanks_html(request):
    return render(request, 'search/add/thanks.html')

def add_site(request):
    site_query = request.POST.get("name")
    site_link_name = request.POST.get("link")
    if site_link_name != None or site_link_name != "":
        sites_link_f = Add_Site.objects.filter(
            site_link=site_link_name
        )
        if str(sites_link_f) != str('<QuerySet []>'):
            return render(request, 'search/add/noThanks.html')
        else:
            name = request.POST.get("name")
            link = request.POST.get("link")
            Add_Site(site_title=name, site_link=link, pub_date=timezone.now()).save()
            #return HttpResponseRedirect(reverse('sites:thanks_html'))
            return render(request, 'search/add/thanks.html')
    else:
        return render(request, 'search/add/index.html')

def add_site_rev(request):
    return HttpResponseRedirect(reverse('search:site_html'))

def add_site_ex(request):
    return HttpResponseRedirect(reverse('search:search_html'))
from django.db import models

class Add_Site(models.Model):
	site_title = models.CharField('Название сайта', max_length=40)
	site_link = models.TextField('Ссылка на сайт')
	pub_date = models.DateTimeField('Дата добавления')

	def __str__(self):
		return self.site_title

	class Meta:
		verbose_name = 'Site'
		verbose_name_plural = 'Sites'
